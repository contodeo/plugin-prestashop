<?php

namespace Wha\Contodeo\services;

use Cart;
use Tools;
use Wha\Contodeo\utils\Configuration;
use Wha\Contodeo\utils\ConfirmationMode;
use Wha\Contodeo\utils\RegisterMode;

class Proxy {

    private $testUrl='https://test-contodeo.w-ha.com/contodeo/api';
   /*private $testUrl='http://localhost:8080/contodeo/api';*/
    private $liveUrl='https://contodeo.w-ha.com/contodeo/api';
    
    /**
     * @var Configuration
     */
    private $configuration;

    /**
     * @var ContodeoWallet
     */
    private $contodeoWallet;
    /**
     * @var Crypto
     */
    private $crypto;
    /**
     * @var Logger
     */
    private $logger;

    public function __construct(){
     
        $this->crypto=\Wha\Contodeo\services\ContodeoServiceLocator::get("\\Wha\Contodeo\services\Crypto");
        $this->configuration=\Wha\Contodeo\services\ContodeoServiceLocator::get("\\Wha\Contodeo\utils\Configuration");
        $this->logger=\Wha\Contodeo\services\ContodeoServiceLocator::get("\\Wha\Contodeo\services\Logger");
        $this->contodeoWallet=\Wha\Contodeo\services\ContodeoServiceLocator::get("\\Wha\Contodeo\models\ContodeoWallet");
    }

    private function getBaseUrl(){
        if($this->configuration->isTestMode())
            return $this->testUrl;
        return $this->liveUrl;
    }

    public function transactionInit($cart, $template)
    {
        
        $url = $this->getBaseUrl().'/transactions/init';
        //$this->configuration=\Wha\Contodeo\services\ContodeoServiceLocator::get("\\Wha\Contodeo\utils\Configuration");

        $autoConfirm=false;
        if($this->configuration->confirmationMode==ConfirmationMode::AUTO){
            $autoConfirm=true;
        }
        
        $walletRegistration=$this->configuration->registerMode;          
        $displayRegisteredCard=$this->configuration->displayRegisteredCard;

        $totalAmount=$cart->getOrderTotal(true, Cart::BOTH);
        $walletId=$this->contodeoWallet->getWalletIdByCustomerId($cart->id_customer);
        
        $httpHost = Tools::getHttpHost(true, true);

        $returnUrl = $httpHost? "http://" : "https://";
        $returnUrl=$returnUrl .$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"];
        $returnUrl=str_replace('iframe','result',$returnUrl);
        $this->logger->info("Computed return url :".$returnUrl) ;
        $data = array(
            'amount' => $totalAmount,
            'currency' => 'EUR',
            'external_id' => ''.$cart->id,
            'auto_confirm' => $autoConfirm,
            'template' => $template,
            'return_url' => $returnUrl,
            'wallet_registration' => $walletRegistration ,
            'display_creditcard_list'=>$displayRegisteredCard
        );
        if($walletId!==false)
            $data['wallet_id']=$walletId;

        $payload = json_encode( $data);
        $timeStamp=time()*1000;
        $StringToSign=$this->configuration->apiKey.':'.$timeStamp.':1:';
        $sign=$this->signContent($StringToSign.$payload);
        $authorizeHeader='authorization: AUTH '.$StringToSign.$sign;
    
        return $this->sendRequest($url,$authorizeHeader,$payload);
    }

    public function getTransaction($trxId)
    {
        
        $url = $this->getBaseUrl().'/transactions/'.$trxId;

        $payload = '';
        $timeStamp=time()*1000;
        $StringToSign=$this->configuration->apiKey.':'.$timeStamp.':1:';
        $sign=$this->signContent($StringToSign.$payload);
        $authorizeHeader='authorization:AUTH '.$StringToSign.$sign;

        return $this->sendRequest($url,$authorizeHeader,$payload);
    }

    public function refundTransaction($trxId,$amount,$refundMerchantId)
    {
        
        $url = $this->getBaseUrl().'/transactions/'.$trxId.'/refund';

        $data = array(
            'amount' => $amount,
            'external_id' => $refundMerchantId
        );
        $payload = json_encode( $data);
        $timeStamp=time()*1000;
        $StringToSign=$this->configuration->apiKey.':'.$timeStamp.':1:';
        $sign=$this->signContent($StringToSign.$payload);
        $authorizeHeader='authorization:AUTH '.$StringToSign.$sign;

        return $this->sendRequest($url,$authorizeHeader,$payload);
    }

    public function createWallet($externalId){
        $url = $this->getBaseUrl().'/wallets';

        $data = array(
            'external_id' => $externalId
        );
        $payload = json_encode( $data);
        $timeStamp=time()*1000;
        $StringToSign=$this->configuration->apiKey.':'.$timeStamp.':1:';
        $sign=$this->signContent($StringToSign.$payload);
        $authorizeHeader='authorization:AUTH '.$StringToSign.$sign;

        return $this->sendRequest($url,$authorizeHeader,$payload);
    }
    public function confirmTransaction($trxId,$amount)
    {
      
        $url = $this->getBaseUrl().'/transactions/'.$trxId.'/confirm';

        $data = array(
            'amount' => $amount
        );
        $payload = json_encode( $data);
        $timeStamp=time()*1000;
        $StringToSign=$this->configuration->apiKey.':'.$timeStamp.':1:';
        $sign=$this->signContent($StringToSign.$payload);
        $authorizeHeader='authorization:AUTH '.$StringToSign.$sign;

        return $this->sendRequest($url,$authorizeHeader,$payload);
    }

    public function sendRequest($url,$authorizeHeader,$payload)
    {

      

        // Create a new cURL resource
        $ch = curl_init($url);

        // Setup request to send json via POST
       

       $this->logger->info("Send request to :".$url.'with data :'.strval($payload)) ;
       

        curl_setopt($ch, CURLOPT_VERBOSE, true);
        
        // Attach encoded JSON string to the POST fields
        if(strlen($payload)>0)
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

        // Set the content type to application/json
       
        error_log("Header envoyé".$authorizeHeader);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json',$authorizeHeader));

        // Return response instead of outputting
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        //Disable CURLOPT_SSL_VERIFYHOST and CURLOPT_SSL_VERIFYPEER by
        //setting them to false.
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        // Execute the POST request
        $result = curl_exec($ch);


        $this->logger->info('Respons from contodeo:'.strval($result));
       
        $curl_error = curl_error($ch);
        // Close cURL resource
        curl_close($ch);

        if($curl_error)
            $this->logger->error($curl_error);

        ini_set('precision', 10);
        ini_set('serialize_precision', 10);
        return json_decode($result);
       
        
    }

    private function signContent($stringToSign){
        $clearKey=$this->crypto->decrypt($this->configuration->encryptedApiKey);
        $this->logger->info('Use clearKey:'.$clearKey);
        $this->logger->info('Sign string:'.$stringToSign);
        return hash_hmac('sha256', $stringToSign,$clearKey);
    }
}