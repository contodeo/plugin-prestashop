<?php

namespace Wha\Contodeo\Services;

use OrderSlip;
use OrderPaymentCore;
use OrderCore;
use Wha\Contodeo\services\ContodeoServiceLocator;

class Transaction{

    /**
     * @var Proxy
     */
    private $proxy;
    /**
     * @var Logger
     */
    private $logger;

    /**
     * @var ContodeoTransaction
     */
    private $transactionModel;

    public function __construct(){
        $this->proxy=ContodeoServiceLocator::get('\\Wha\\Contodeo\\services\\Proxy');
        $this->logger=ContodeoServiceLocator::get('\\Wha\\Contodeo\\services\\Logger');
        $this->transactionModel=ContodeoServiceLocator::get('\\Wha\\Contodeo\\models\\ContodeoTransaction');
        $this->walletModel=\Wha\Contodeo\services\ContodeoServiceLocator::get("\\Wha\Contodeo\models\ContodeoWallet");
    }

    /**
     * @param Order $order
     * @param OrderSlip $orderSlip
     *
     * @return bool
     */
    public function refundTransaction(OrderCore $order, OrderSlip $orderSlip){
 
       
        $orderPayment=OrderPaymentCore::getByOrderReference($order->reference);
        $refundReference="R-".$order->reference;    
        $this->logger->info('call  refund with thransaction_id:'.$orderPayment[0]->transaction_id.' '.'Reference:'.$orderPayment[0]->order_reference);
        $result=$this->proxy->refundTransaction($orderPayment[0]->transaction_id,$orderSlip->total_products_tax_incl,$refundReference);
        if($result->status=='CONFIRMED')
            return true;
        return false;
    }

    /**
     * @param Order $order
     * @param OrderSlip $orderSlip
     *
     * @return bool
     */
    public function refundOrder(OrderCore $order){
 
       
        $orderPayment=OrderPaymentCore::getByOrderReference($order->reference);
        $refundReference="R-".$order->reference;    
        $this->logger->info('call  refund with thransaction_id:'.$orderPayment[0]->transaction_id.' '.'Reference:'.$orderPayment[0]->order_reference);
        $result=$this->proxy->refundTransaction($orderPayment[0]->transaction_id,$orderPayment[0]->amount,$refundReference);
        if($result->status=='CONFIRMED')
            return true;
        return false;
    }

    /**
     * @param Order $order
     *
     *
     * @return bool
     */
    public function confirmTransaction(OrderCore $order, String $transactionId){
 

        $result=$this->proxy->confirmTransaction($transactionId,$order->total_paid);

        $this->transactionModel->updateTransactionByOrderId($order->id, $result->status, $result);
        
        return $result;
    }

    public function transactionInit($cart,$template){
      
        $wallet=$this->walletModel->getWalletIdByCustomerId($cart->id_customer);

        if($wallet==null)
        {
            $remoteWallet=$this->proxy->createWallet($cart->id_customer);
            $this->walletModel->insertWallet($cart->id_customer,$remoteWallet->id);
            $this->logger->info('Register wallet for customer : '. $cart->id_customer.  'wallet ' .$remoteWallet->id );
        }
        $result=$this->proxy->transactionInit($cart,$template);
        return $result;
    }

    public function getTransaction($trxId)
    {
       return  $this->proxy->getTransaction($trxId);
    }


}
