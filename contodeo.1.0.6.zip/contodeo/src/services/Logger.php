<?php


namespace wha\contodeo\services;

use Wha\Contodeo\utils\VersionChecker;
use wha\Contodeo\utils\CommandException;

use Monolog\Handler\StreamHandler;

class Logger extends \Monolog\Logger
{
    const NAME = 'CONTODEO';
    const CONTODEO_API = 201;
    const CONTODEO_RESULT = 202;
    const CONTODEO_NOTIFICATION = 203;
    const CONTODEO_CRONJOB = 204;

    private static $contodeoHandlers = array(
        self::DEBUG => array(
            'level' => self::DEBUG,
            'fileName' => 'debug.log'
        ),
        self::INFO => array(
            'level' => self::INFO,
            'fileName' => 'info.log'
        ),
        self::CONTODEO_API => array(
            'level' => self::CONTODEO_API,
            'fileName' => 'contodeo_api.log'
        ),
        self::CONTODEO_RESULT => array(
            'level' => self::CONTODEO_RESULT,
            'fileName' => 'contodeo_result.log'
        ),
        self::CONTODEO_NOTIFICATION => array(
            'level' => self::CONTODEO_NOTIFICATION,
            'fileName' => 'contodeo_notification.log'
        ),
        self::CONTODEO_CRONJOB => array(
            'level' => self::CONTODEO_CRONJOB,
            'fileName' => 'contodeo_cronjob.log'
        ),
        self::NOTICE => array(
            'level' => self::NOTICE,
            'fileName' => 'notice.log'
        ),
        self::WARNING => array(
            'level' => self::WARNING,
            'fileName' => 'warning.log'
        ),
        self::ERROR => array(
            'level' => self::ERROR,
            'fileName' => 'error.log'
        ),
    );

    /**
     * Logging levels from syslog protocol defined in RFC 5424
     * Overrule the default to add Contodeo specific loggers to log into separate files
     *
     * @var array $levels Logging levels
     */
    protected static $levels = array(
        self::DEBUG => 'DEBUG',
        self::INFO => 'INFO',
        self::CONTODEO_API => 'CONTODEO_API',
        self::CONTODEO_RESULT => 'CONTODEO_RESULT',
        self::CONTODEO_NOTIFICATION => 'CONTODEO_NOTIFICATION',
        self::CONTODEO_CRONJOB => 'CONTODEO_CRONJOB',
        self::NOTICE => 'NOTICE',
        self::WARNING => 'WARNING',
        self::ERROR => 'ERROR',
        self::CRITICAL => 'CRITICAL',
        self::ALERT => 'ALERT',
        self::EMERGENCY => 'EMERGENCY',
    );

    /**
     * @var VersionChecker
     */
    private $versionChecker;

    /**
     * Logger constructor.
     *
     * @param VersionChecker $versionChecker
     * @throws \Exception
     */
    public function __construct(
        VersionChecker $versionChecker
    ) {
        parent::__construct(self::NAME);
        $this->versionChecker = $versionChecker;
        $this->registerContodeoLogHandlers();
    }

    /**
     * Retrieve default log path depending on the PrestaShop version
     *
     * @return string
     */
    private function getLogPath()
    {
        if ($this->versionChecker->isPrestaShop16()) {
            $path = _PS_ROOT_DIR_ . '/log';
        } else {
            $path = _PS_ROOT_DIR_ . '/var/logs';
        }

        return $path;
    }

    /**
     * Retrieve Contodeo log path
     * If it doesn't exist yet then also creates it
     *
     * @return string
     * @throws CommandException
     */
    private function getContodeoLogPath()
    {
        $path = $this->getLogPath() . '/contodeo';

        if (!file_exists($path)) {
            if (!mkdir($path, 0755, true)) {
                throw new CommandException('Creating the Contodeo log folder failed');
            }
        }

        return $path;
    }

    /**
     * @param string $message
     * @param array $context
     * @return bool
     */
    public function addContodeoAPI($message, array $context = array())
    {
        return $this->addRecord(static::CONTODEO_API, $message, $context);
    }

    /**
     * @param string $message
     * @param array $context
     * @return bool
     */
    public function addContodeoResult($message, array $context = array())
    {
        return $this->addRecord(static::CONTODEO_RESULT, $message, $context);
    }

    /**
     * @param string $message
     * @param array $context
     * @return bool
     */
    public function addContodeoNotification($message, array $context = array())
    {
        return $this->addRecord(static::CONTODEO_NOTIFICATION, $message, $context);
    }

    /**
     * @param string $message
     * @param array $context
     * @return bool
     */
    public function addContodeoCronjob($message, array $context = array())
    {
        return $this->addRecord(static::CONTODEO_CRONJOB, $message, $context);
    }

    /**
     * Adds a log record.
     *
     * @param integer $level The logging level
     * @param string $message The log message
     * @param array $context The log context
     * @return Boolean Whether the record has been processed
     */
    public function addRecord($level, $message, array $context = array())
    {
        $context['is_exception'] = $message instanceof \Exception;
        return parent::addRecord($level, $message, $context);
    }

    /**
     * @throws CommandException
     */
    private function registerContodeoLogHandlers()
    {
        $contodeoLogPath = $this->getContodeoLogPath();

        foreach (self::$contodeoHandlers as $contodeoHandler) {
            $this->pushHandler(new StreamHandler(
                $contodeoLogPath . '/' . $contodeoHandler['fileName'],
                $contodeoHandler['level'],
                false
            ));
        }
    }
}
