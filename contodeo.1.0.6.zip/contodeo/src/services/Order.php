<?php

namespace Wha\Contodeo\Services;

class Order
{
    public function addPaymentDataToOrderFromResponse($order, $response)
    {
        
        if (\Validate::isLoadedObject($order)) {
            // Save available data into the order_payment table
            $paymentCollection = $order->getOrderPaymentCollection();
            foreach ($paymentCollection as $payment) {
                $cardPan = !empty($response->creditcard->pan)
                    ? pSQL($response->creditcard->pan)
                    : '******';
                $paymentMethod = !empty($response->creditcard->brand)
                    ? pSQL($response->creditcard->brand)
                    : 'Contodeo';
                $expiryDate = !empty($response->creditcard->expiry_date)
                    ? pSQL($response->creditcard->expiry_date)
                    : '';
               // $cardHolderName = !empty($response['creditcard']['cardHolderName'])
               //    ? pSQL($response['creditcard']['cardHolderName']) : '';
                $payment->card_number = $cardPan;
                $payment->card_brand = $paymentMethod;
                $payment->card_expiration = $expiryDate;
               // $payment->card_holder = $cardHolderName;
                $payment->save();
              
            }
        }
    }
}
