<?php

namespace Wha\Contodeo\utils;

class Environment
{
    const TEST = "test";
    const LIVE = "live";
}
