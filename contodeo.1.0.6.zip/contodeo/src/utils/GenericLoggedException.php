<?php

namespace Wha\Contodeo\utils;

use Exception;

class GenericLoggedException extends Exception
{

}
