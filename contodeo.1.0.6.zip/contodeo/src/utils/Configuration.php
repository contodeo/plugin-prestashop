<?php

namespace Wha\Contodeo\utils;



use Tools;

class Configuration
{
   
    /**
     * @var string
     */
    public $contodeoMode;

   /**
     * @var string
     */
    public $confirmationMode;

     /**
     * @var string
     */
    public $registerMode;


    /**
     * @var boolean
     */
    public $displayRegisteredCard;

    /**
     * @var string
     */
    public $encryptedApiKey;

    /**
     * @var string
     */
    public $liveEndpointPrefix;

    /**
     * @var string
     */
    public $moduleVersion;


    /**
     * @var string
     */
    public $moduleName;
    /**
     * @var string
     */
    public $apiKey;
    /**
     * @var Logger
     */
    private $logger;

    /**
     * Configuration constructor.
     *
     * @param Logger $logger
     */
    public function __construct()
    {
      
        $this->httpHost = Tools::getHttpHost(true, true);
        $contodeoModeConfiguration = \Configuration::get('CONTODEO_MODE');
        $confirmationModeConfiguration = \Configuration::get('CONTODEO_CONFIRM_MODE');
        $registerModeConfiguration = \Configuration::get('CONTODEO_REGISTER_MODE');
        $displayMode=\Configuration::get('CONTODEO_DISPLAY_REGISTERED_CARD');
        $this->contodeoMode = !empty($contodeoModeConfiguration) ? $contodeoModeConfiguration : Environment::TEST;
        $this->confirmationMode = !empty($confirmationModeConfiguration) ? $confirmationModeConfiguration : ConfirmationMode::AUTO;
        $this->registerMode = !empty($registerModeConfiguration) ? $registerModeConfiguration : RegisterMode::NONE;
        $this->displayRegisteredCard= !empty($displayMode)?$displayMode === 'true': false;
        $this->sslEncryptionKey = _COOKIE_KEY_;
        $this->encryptedApiKey = $this->getEncryptedAPIKey($this->contodeoMode);
        $this->apiKey=\Configuration::get('CONTODEO_API_PUBLIC_KEY');

        
        $this->moduleVersion = '1.0';
        $this->moduleName = 'contodeo';
    }

    /**
     * Retrieves the encrypted API key based on the mode set in the admin configurations
     *
     * @param string $contodeoRunningMode
     * @return string
     */
    private function getEncryptedAPIKey($contodeoRunningMode)
    {
        if ($this->isTestMode($contodeoRunningMode)) {
            $encryptedApiKey = \Configuration::get('CONTODEO_API_PRIVATE_KEY_TEST');
        } else {
            $encryptedApiKey = \Configuration::get('CONTODEO_API_PRIVATE_KEY_LIVE');
        }
        return $encryptedApiKey;
    }

    /**
     * Checks if plug-in is running in test mode or not
     *
     * @return bool
     */
    public  function isTestMode()
    {

        if (strpos($this->contodeoMode, Environment::TEST) !== false) {
            return true;
        } else {
            return false;
        }
    }
}
