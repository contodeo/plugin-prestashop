<?php


namespace Wha\Contodeo\utils;

use Exception;

class CommandException extends Exception
{

}
