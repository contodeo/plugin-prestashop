<?php

namespace Wha\Contodeo\utils;

class ConfirmationMode
{
    const AUTO = "auto";
    const ON_DISPATCH = "onDispatch";
    const MANUAL = "manual";
}
