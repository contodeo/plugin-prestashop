<?php

namespace Wha\Contodeo\utils;

class RegisterMode
{
    const NONE = "no";
    const SUGGEST = "suggest";
    const MANDATORY = "suggest_mandatory";
}
