<?php

namespace Wha\Contodeo\models;

class ContodeoWallet extends AbstractModel
{
    private static $tableName = 'contodeo_wallet';
  
    /**
     * @param $customerId
     * @param $walletId
     * @param $response
     * @return bool
     */
    public function insertWallet($customerId,$walletId)
    {

        $result=$this->getWalletIdByCustomerId($customerId);
        
        if($result!=null)
            return false;
            
        $data = array(
            'wallet_id' => $walletId,
            'customer_id' => (int)$customerId);

        return $this->dbInstance->insert(self::$tableName, $data);
    }

    /**
     * @param $customerId
     * @return array|bool|object|null
     */
    public function getWalletIdByCustomerId($customerId)
    {
        $sql = 'SELECT `wallet_id` FROM ' . _DB_PREFIX_ . self::$tableName
            . ' WHERE `customer_id` = "' . (int)$customerId . '"';

        return $this->dbInstance->getValue($sql);
    }

   

    /**
     * @param $customerId
     * @return bool
     */
    public function deleteWalletByCustomerId($customerId)
    {
        return $this->dbInstance->delete(self::$tableName, '`customer_id` = "' . (int)$customerId . '"');
    }

    /**
     * @param $param
     * @return mixed
     */
    private function jsonEncodeIfArray($param)
    {
        if (is_array($param)) {
            return json_encode($param);
        }

        return $param;
    }

    /**
     * @param $param
     * @return mixed
     */
    private function jsonDecodeIfJson($param)
    {
        $jsonDecoded = json_decode($param, true);

        if (json_last_error() == JSON_ERROR_NONE) {
            return $jsonDecoded;
        }

        return $param;
    }
}
