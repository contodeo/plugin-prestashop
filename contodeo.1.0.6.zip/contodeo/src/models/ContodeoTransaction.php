<?php

namespace Wha\Contodeo\models;

class ContodeoTransaction extends AbstractModel
{
    private static $tableName = 'contodeo_transaction';

    /**
     * @param $cartId
     * @param $resultCode
     * @param $response
     * @return bool
     */
    public function insertTransaction($cartId,$orderId, $resultCode, $response)
    {
        $data = array(
            'cart_id' => (int)$cartId,
            'order_id' => (int)$orderId,
            'transaction_id'=>pSQL($response->id),
            'result_code' => pSQL($resultCode),
            'response' => pSQL(json_encode($response))
        );

        return $this->dbInstance->insert(self::$tableName, $data);
    }

    /**
     * @param $transactionId
     * @return json
     */
    public function getTransactionByTransactionId($transactionId)
    {

        $sql = 'SELECT `response` FROM ' . _DB_PREFIX_ . self::$tableName
            . ' WHERE `transaction_id` = "' . $transactionId . '"';

        return json_decode($this->jsonEncodeIfArray(
            $this->dbInstance->getValue($sql)
        ),false);
    }

      /**
     * @param $transactionId
     * @return json
     */
    public function getOrderIdByTransactionId($transactionId)
    {
        $sql = 'SELECT `order_id` FROM ' . _DB_PREFIX_ . self::$tableName
            . ' WHERE `transaction_id` = "' . $transactionId . '"';

        return $this->dbInstance->getValue($sql);
    }

     /**
     * @param $cartId
     * @return json
     */
    public function getTransactionByOrderId($orderId)
    {
        $sql = 'SELECT `response` FROM ' . _DB_PREFIX_ . self::$tableName
            . ' WHERE `order_id` = "' . (int)$orderId . '"';

        return json_decode($this->jsonEncodeIfArray(
            $this->dbInstance->getValue($sql)
        ),false);
    }

    /**
     * @param $cartId
     * @param $resultCode
     * @param $response
     * @return bool
     */
    public function updateTransactionByCartId($cartId, $orderId, $resultCode, $response)
    {
        $data = array(
            'result_code' => $resultCode,
            'response' => json_encode($response),
            'order_id' => $orderId
        );

        return $this->dbInstance->update( self::$tableName, $data, '`cart_id` = "' . (int)$cartId . '"');
    }

      /**
     * @param $orderId
     * @param $resultCode
     * @param $response
     * @return bool
     */
    public function updateTransactionByOrderId($orderId, $resultCode, $response)
    {
        $data = array(
            'result_code' => $resultCode,
            'response' => json_encode($response),
            'order_id' => $orderId
        );

        return $this->dbInstance->update( self::$tableName, $data, '`order_id` = "' . (int)$orderId . '"');
    }

    /**
     * @param $transactionId
     * @param $resultCode
     * @param $response
     * @return bool
     */
    public function updateTransactionByTransactionId($transactionId, $resultCode, $response)
    {
        $data = array(
            'result_code' => $resultCode,
            'response' => json_encode($response)
        );

        return $this->dbInstance->update( self::$tableName, $data, '`transaction_id` = "' . (int)$transactionId . '"');
    }


    /**
     * @param $cartId
     * @return bool
     */
    public function deleteTransactionByCartId($cartId)
    {
        return $this->dbInstance->delete(_DB_PREFIX_ . self::$tableName, '`cart_id` = "' . (int)$cartId . '"');
    }

    /**
     * @param $param
     * @return mixed
     */
    private function jsonEncodeIfArray($param)
    {
        if (is_array($param)) {
            return json_encode($param);
        }

        return $param;
    }

    /**
     * @param $param
     * @return mixed
     */
    private function jsonDecodeIfJson($param)
    {
        $jsonDecoded = json_decode($param, true);

        if (json_last_error() == JSON_ERROR_NONE) {
            return $jsonDecoded;
        }

        return $param;
    }
}
