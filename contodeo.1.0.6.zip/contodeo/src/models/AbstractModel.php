<?php

namespace Wha\Contodeo\models;

abstract class AbstractModel
{
    /**
     * @var \Db
     */
    protected $dbInstance;

    public function __construct()
    {
        $this->dbInstance = \Db::getInstance();
    }
}
