<?php
/*
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

use PrestaShop\PrestaShop\Adapter\ServiceLocator;
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;
use Wha\Contodeo\services\Crypto;

Use Wha\Contodeo\services\ContodeoServiceLocator;
use Wha\Contodeo\utils\ConfirmationMode;

//use Psr\Log\LoggerInterface;

if (!defined('_PS_VERSION_')) {
    exit;
}

require _PS_ROOT_DIR_ . '/modules/contodeo/vendor/autoload.php';

class Contodeo extends PaymentModule
{

    private $crypto;
    private $configuration;
    private $logger;
    private $contodeoTransaction;
    protected $_html = '';
    protected $_postErrors = array();

    public $details;
    public $owner;
    public $address;
    public $extra_mail_vars;


    public function __construct()
    {
        $this->name = 'contodeo';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.6';
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->author = 'w-ha';
        $this->controllers = array('validation');
        $this->is_eu_compatible = 1;
        $this->need_instance = 1;
        $this->page = basename(__FILE__, '.php');
        $this->currencies = true;
        $this->currencies_mode = 'checkbox';
      //  $this->logger=$logger;
        $this->bootstrap = true;
      

        //if (!count(Currency::checkPaymentCurrencies($this->id))) {
        //    $this->warning = $this->l('No currency has been set for this module.');
        //}
       // $crypto =$crypt;
        //$this->get('wha.contodeo.services.Crypto');

        //$this->crypto= $this->get('Crypto::class');
        // ServiceLocator::get('\Contodeo\PrestaShop\service\utils\Crypto');
        
       
        $this->logger = ContodeoServiceLocator::get('\\Wha\\Contodeo\\services\\Logger');
        $this->contodeoTransaction=ContodeoServiceLocator::get('\\Wha\\Contodeo\\models\\ContodeoTransaction');
        $this->transactionService=ContodeoServiceLocator::get('\\Wha\\Contodeo\\services\\Transaction');
        $this->versionChecker =ContodeoServiceLocator::get('\\Wha\\Contodeo\\utils\\VersionChecker');
        /*$this->configuration = \Contodeo\PrestaShop\service\utils\ServiceLocator::get(
            'Contodeo\PrestaShop\service\utils\Configuration'
        );*/ 
        parent::__construct();
        $this->dependencies = array();

        $this->displayName = $this->l('Contodeo');
        $this->description = $this->l('Contodeo payment services');
        
    }

    

    public function install()
    {
        

        $this->l('Test dashboard');
        $this->l('Production dashboard');
        $this->l('You will find your api access key into the merchant section of Contodeo dashboard');
        $this->l('If you don\'t know your Api private key, log in to your Contodeo Dashboard. Navigate to Merchant tab. The key is display on the upper part of the page.');


        if (!$this->versionChecker->isPrestaShopSupportedVersion()) {
            $this->_errors[] = $this->l('Sorry, this module is not compatible with your version.');
            return false;
        }

        // Version 1.6
        if ($this->versionChecker->isPrestaShop16()) {
            if (parent::install() &&

                $this->registerHook('payment') &&
                $this->registerHook('paymentReturn') &&
                $this->registerHook('actionOrderSlipAdd') &&   
                $this->registerHook('actionOrderStatusUpdate') &&         
                $this->createWaitingForPaymentOrderStatus() &&
                $this->createContodeoTables()
            ) {
                return true;
            } else {
                $this->logger->debug('Contodeo module: installation failed!');
                return false;
            }
        }

        // Version 1.7 or higher
        if (parent::install() &&
            $this->registerHook('paymentOptions') &&
            $this->registerHook('paymentReturn') &&
            $this->registerHook('actionOrderSlipAdd') &&
            $this->registerHook('actionOrderStatusUpdate') &&
            $this->createWaitingForPaymentOrderStatus() &&
            $this->createContodeoTables()
        ) {
            return true;
        } else {
            $this->logger->debug('Contodeo module: installation failed!');
            return false;
        }
    }

    public function uninstall()
    {
        return parent::uninstall() &&
            $this->removeContodeoDatabaseTables() &&
            $this->removeConfigurationsFromDatabase();
    }

    /**
     * Reset script
     *
     * This function is called when User resets the module and selects the reset only the parameters option
     *
     * @return bool
     */
    public function reset()
    {
        if ($this->removeConfigurationsFromDatabase()) {
            return true;
        } else {
            $this->logger->debug('Contodeo module: reset failed!');
            return false;
        }
    }

    /**
     * Determine if PrestaShop is 1.6 or not
     *
     * @return bool
     */
    public function isPrestaShop16()
    {
        if (version_compare(_PS_VERSION_, '1.6', '>=')
            && version_compare(_PS_VERSION_, '1.7', '<')
        ) {
            return true;
        }
        return false;
    }

    private function removeContodeoDatabaseTables()
    {
        $db = Db::getInstance();
        return $db->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'contodeo_transaction`') &&
            $db->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'contodeo_wallet`');
    }

    /**
     * Removes Contodeo settings from configuration table
     *
     * @return bool
     */
    private function removeConfigurationsFromDatabase()
    {
        $configurationNames = array(
            'CONTODEO_API_PUBLIC_KEY',
            'CONTODEO_MODE',
            'CONTODEO_API_PRIVATE_KEY_TEST',
            'CONTODEO_API_PRIVATE_KEY_LIVE',
            'CONTODEO_CONFIRM_MODE',
            'ADYEN_APIKEY_LIVE',
            'CONTODEO_CONFIRM_MODE',
            'CONTODEO_DISPLAY_REGISTERED_CARD'
        );

        $result = true;

        foreach ($configurationNames as $configurationName) {
            if (!Configuration::deleteByName($configurationName)) {
                $this->logger->debug("Configuration couldn't be deleted by name: " . $configurationName);
                $result = false;
            }
        }

        return $result;
    }

    public function createContodeoTables(){
        $result=$this->createContodeoTransactionTable()&&$this->createContodeoWalletTable();
        $this->logger->info('Create contodeo tables:'.$result);
        return $result;
    }
    
     /**
     * @return bool
     */
    public function createContodeoTransactionTable()
    {
        $this->logger->info('Create transaction table');
        $db = Db::getInstance();
        $query = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'contodeo_transaction` (
            `entity_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT \'Contodeo transaction Entity ID\',
            `cart_id` int(11) DEFAULT NULL COMMENT \'Prestashop cart id\',
            `order_id` int(11) DEFAULT NULL COMMENT \'Prestashop order id\', 
            `transaction_id` varchar(50) DEFAULT NULL COMMENT \'Contodeo transaction id\', 
            `result_code` varchar(255) DEFAULT NULL COMMENT \'Result code\',
            `response` text COMMENT \'Response\',
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT \'Created At\',
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            COMMENT \'Updated At\',
            PRIMARY KEY (`entity_id`),
            KEY `CONTODEO_TRANSACTION_CART_IDX` (`cart_id`),
            KEY `CONTODEO_TRANSACTION_ORDER_IDX` (`order_id`),
            KEY `CONTODEO_TRANSACTION_TRX_IDX` (`transaction_id`)            
            ) ENGINE=' . _MYSQL_ENGINE_ . ' AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT=\'Contodeo transaction Action\'';

        return $db->execute($query);
    }
     /**
     * @return bool
     */
    public function createContodeoWalletTable()
    {
        $this->logger->info('Create wallet table');
        $db = Db::getInstance();
        $query = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'contodeo_wallet` (
            `entity_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT \'Contodeo wallet Entity ID\',
            `customer_id` int(11) DEFAULT NULL COMMENT \'Prestashop customer id\',
            `wallet_id` varchar(255) DEFAULT NULL COMMENT \'Contodeo Wallet reference\',
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT \'Created At\',
            `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            COMMENT \'Updated At\',
            PRIMARY KEY (`entity_id`),
            KEY `CUSTOMER_ID` (`customer_id`),
            KEY `WALLET_ID` (`wallet_id`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT=\'Contodeo wallet\'';

        return $db->execute($query);
    }

    /**
     * Create a new order status: "waiting for payment"
     *
     * @return mixed
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public function createWaitingForPaymentOrderStatus()
    {
        if (!Configuration::get('CONTODEO_OS_WAITING_FOR_PAYMENT')) {
            $order_state = new OrderState();
            $order_state->name = array();
            foreach (Language::getLanguages() as $language) {
                if($language['iso_code']=='fr')
                    $order_state->name[$language['id_lang']] = 'Paiement par carte - confirmation en attente';
                else 
                    $order_state->name[$language['id_lang']] = 'Waiting for payment';
            }

            $order_state->send_email = false;
            $order_state->invoice = false;
            $order_state->color = '#4169E1';
            $order_state->logable = true;
            $order_state->delivery = false;
            $order_state->hidden = false;
            $order_state->shipped = false;
            $order_state->paid = false;
            if ($order_state->add()) {
                $source = _PS_ROOT_DIR_ . '/img/os/' . Configuration::get('PS_OS_BANKWIRE') . '.gif';
                $destination = _PS_ROOT_DIR_ . '/img/os/' . (int)$order_state->id . '.gif';
                copy($source, $destination);
            }

            return Configuration::updateValue('CONTODEO_OS_WAITING_FOR_PAYMENT', (int)$order_state->id);
        }

        return true;
    }
/**
     * Create a new order status: "authorize expired"
     *
     * @return mixed
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public function createAuthorizeExpiredOrderStatus()
    {
        if (!Configuration::get('CONTODEO_OS_AUTHORIZE_EXPIRED')) {
            $order_state = new OrderState();
            $order_state->name = array();
            foreach (Language::getLanguages() as $language) {
                if($language['iso_code']=='fr')
                    $order_state->name[$language['id_lang']] = 'Autorisation de paiement expirée';
                else 
                    $order_state->name[$language['id_lang']] = 'Authorize expired';
            }

            $order_state->send_email = false;
            $order_state->invoice = false;
            $order_state->color = '#e14641';
            $order_state->logable = true;
            $order_state->delivery = false;
            $order_state->hidden = false;
            $order_state->shipped = false;
            $order_state->paid = false;
            if ($order_state->add()) {
                $source = _PS_ROOT_DIR_ . '/img/os/' . Configuration::get('PS_OS_BANKWIRE') . '.gif';
                $destination = _PS_ROOT_DIR_ . '/img/os/' . (int)$order_state->id . '.gif';
                copy($source, $destination);
            }

            return Configuration::updateValue('CONTODEO_OS_AUTHORIZE_EXPIRED', (int)$order_state->id);
        }

        return true;
    }
    public function hookActionOrderStatusUpdate($params){
        
        $transaction=$this->contodeoTransaction->getTransactionByOrderId($params['id_order']);

        $this->logger->info('Changing status to '.$params['newOrderStatus']->id.'for order :'.$params['id_order']);
        $this->logger->info('Current status for linked contodeoTransaction : '. print_r($transaction, true));
        $confirmationMode= Configuration::get('CONTODEO_CONFIRM_MODE');

        if(($params['newOrderStatus']->id.''==\Configuration::get('PS_OS_PAYMENT')||
            $params['newOrderStatus']->id.''==\Configuration::get('PS_OS_DELIVERED')|| 
            $params['newOrderStatus']->id.''==\Configuration::get('PS_OS_SHIPPING'))&&
          $transaction->status=='AUTHORIZED')
        {
            
            $order = new \Order($params['id_order']);
            if ($confirmationMode==ConfirmationMode::ON_DISPATCH) {
                $this->transactionService->confirmTransaction($order,$transaction->id);
                $this->logger->info('Authorization for order was confirmed');
            }
           
        }else if($params['newOrderStatus']->id.''==\Configuration::get('PS_OS_REFUND')&&
                 $transaction->status=='CONFIRMED'){
            $order = new \Order($params['id_order']);
            $this->transactionService->refundOrder($order);
            $this->logger->info('Authorization for order was refund');

        }    
        $this->logger->info('Before return for hookActionOrderStatusUpdate');
    }

    public function hookPaymentReturn($params)
    {
 

        if (!$this->active) {
            return null;
        }

        if ($this->isPrestaShop16()) {
            $order = $params['objOrder'];
        } else {
            $order = $params['order'];
        }

        // Check if order object is not empty
        if (empty($order)) {
            $this->logger->debug('In hookPaymentReturn Order object is empty');
            return null;
        }

        $confirmationMode= Configuration::get('CONTODEO_CONFIRM_MODE');
        if ($confirmationMode==ConfirmationMode::AUTO) {
            $transaction=$this->contodeoTransaction->getTransactionByOrderId($order->id);
            $this->transactionService->confirmTransaction($order,$transaction->id);
            $this->logger->info('Authorization for order was confirmed');
        }

        $orderPayment=OrderPaymentCore::getByOrderReference($order->reference);

        $smartyVariables = array(
            'isPrestaShop16' => $this->isPrestaShop16() ? 'true' : 'false',
            'paymentMethodsResponse' => '{}',
            'trxAmount' => $order->total_paid,
            'trxDate' => $orderPayment[0]->date_add,
            'trxRef' => $orderPayment[0]->transaction_id
        );

        // Assign variables to frontend
        $this->context->smarty->assign($smartyVariables);
        
      
        return $this->display(__FILE__, '/views/templates/front/paymentSummary.tpl');
        //return $this->context->smarty->fetch('module:contodeo/views/templates/front/payment_return.tpl');
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        if (!$this->checkCurrency($params['cart'])) {
            return;
        }

        $payment_options = [
            $this->getIframePaymentOption(),
        ];

        return $payment_options;
    }


    /**
     * @param array $params
     * @return void|null
     */
    public function hookActionOrderSlipAdd(array $params)
    {
        
        if (!$this->active) {
            return null;
        }
        
        $transactionService=ContodeoServiceLocator::get('\\Wha\\Contodeo\\services\\Transaction');
       
         /** @var Order $order */
        $order = $params['order'];

        try {
            /** @var OrderSlip $orderSlip */
            $orderSlip = $order->getOrderSlipsCollection()->orderBy('date_upd', 'desc')->getFirst();
          
        } catch (PrestaShopException $e) {
            
            return;
        }
      
        
        $transactionService->refundTransaction($order,$orderSlip);
       
    }


    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);

        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

   

    public function getIframePaymentOption()
    {
        $iframeOption = new PaymentOption();
        $iframeOption->setCallToActionText($this->l('Pay by card'))
                     ->setAction($this->context->link->getModuleLink($this->name, 'iframe', array(), true))
                     ->setAdditionalInformation($this->context->smarty->fetch('module:contodeo/views/templates/front/payment_infos.tpl'))
                     ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/cb-visa-mastercard-110-22px.png'));

        return $iframeOption;
    }

    protected function generateForm()
    {
        $months = [];
        for ($i = 1; $i <= 12; $i++) {
            $months[] = sprintf("%02d", $i);
        }

        $years = [];
        for ($i = 0; $i <= 10; $i++) {
            $years[] = date('Y', strtotime('+'.$i.' years'));
        }

        $this->context->smarty->assign([
            'action' => $this->context->link->getModuleLink($this->name, 'validation', array(), true),
            'months' => $months,
            'years' => $years,
        ]);

        return $this->context->smarty->fetch('module:contodeo/views/templates/front/payment_form.tpl');
    }

    
/**
     * shows the configuration page in the back-end
     */

    public function getContent()
    {
        $output = null;

        

        $this->createAuthorizeExpiredOrderStatus();
        //$this->crypto= $this->context->controller->getContainer()->get('wha.contodeo.services.Crypto') ;
        
        $this->crypto=ContodeoServiceLocator::get('\\Wha\\Contodeo\\services\\Crypto');

        if (Tools::isSubmit('submit' . $this->name)) {
            // get post values
            $merchant_account = (string)Tools::getValue('CONTODEO_API_PUBLIC_KEY');
            $mode = (string)Tools::getValue('CONTODEO_MODE');

            $api_key_test = Tools::getValue('CONTODEO_API_PRIVATE_KEY_TEST');
            $api_key_live = Tools::getValue('CONTODEO_API_PRIVATE_KEY_LIVE');
            
            $contodeo_confirm_mode=Tools::getValue('CONTODEO_CONFIRM_MODE');
            $contodeo_register_mode=Tools::getValue('CONTODEO_REGISTER_MODE');
            $display_register_card=Tools::getValue('CONTODEO_DISPLAY_REGISTERED_CARD');

            // validating the input
            if (empty($merchant_account) || !Validate::isGenericName($merchant_account)) {
                $output .= $this->displayError($this->l('Invalid Configuration value for API ACCESS KEY'));
            }

            

            if ($output == null) {
                Configuration::updateValue('CONTODEO_API_PUBLIC_KEY', $merchant_account);
                Configuration::updateValue('CONTODEO_MODE', $mode);
                Configuration::updateValue('CONTODEO_CONFIRM_MODE', $contodeo_confirm_mode);
                Configuration::updateValue('CONTODEO_REGISTER_MODE', $contodeo_register_mode);
                Configuration::updateValue('CONTODEO_DISPLAY_REGISTERED_CARD', $display_register_card);
                
                if (!empty($api_key_test)) {
                    Configuration::updateValue('CONTODEO_API_PRIVATE_KEY_TEST', $this->crypto->encrypt($api_key_test));
                }

                if (!empty($api_key_live)) {
                    Configuration::updateValue('CONTODEO_API_PRIVATE_KEY_LIVE', $this->crypto->encrypt($api_key_live));
                }
               

                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }
        return $output . $this->displayGetStarted(). $this->displayForm();
    }

    /**
     * @return string
     */
    private function displayGetStarted()
    {
       

        $smartyVariables = array(
            'logo' => Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/logo-Contodeo.png'),
            'links' => array(
                array(
                    "label" => $this->l("Documents"),
                    "url" => "https://specifications.contodeo.com"
                ),
                array(
                    "label" => $this->l("Support"),
                    "url" => "https://contodeo.com/support/"
                ),
                array(
                    "label" => $this->l("Test dashboard"),
                    "url" => "https://test-contodeo.com/contodeo-csr/"
                ),
                array(
                    "label" => $this->l("Production dashboard"),
                    "url" => "https://contodeo.com/contodeo-csr/"
                )
            )
        );

        $this->context->smarty->assign($smartyVariables);

        return $this->display(__FILE__, '/views/templates/front/information.tpl');
    }

    /**
     * @return mixed
     */
    public function displayForm()
    {
        $this->context->controller->addCSS('modules/' . $this->name . '/views/css/contodeo-admin.css', 'all');

        // Get default Language
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

        // Init Fields form array
        $fields_form = array(array());

        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('General Settings'),
                'image' => '../img/admin/edit.gif'
            ),
            'input' => array(),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            )
        );

        $fields_form[1]['form'] = array(
            'legend' => array(
                'title' => $this->l('Merchant details'),
                'image' => '../img/admin/edit.gif'
            ),
            'input' => array(),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            )
        );

        // Merchant account input
        $fields_form[0]['form']['input'][] = array(
            'type' => 'text',
            'label' => $this->l('API Public access key'),
            'name' => 'CONTODEO_API_PUBLIC_KEY',
            'size' => 20,
            'required' => true,
            'lang' => false,
            'hint' => $this->l('You will find your api access key into the merchant section of Contodeo dashboard')
        );

        $apiKeyTest = '';

        try {
           $apiKeyTest = $this->crypto->decrypt(Configuration::get('CONTODEO_API_PRIVATE_KEY_TEST'));
       } catch (\Wha\Contodeo\utils\GenericLoggedException $e) {
            $this->logger->error(
               'For configuration "CONTODEO_API_PRIVATE_KEY_TEST" an exception was thrown: ' . $e->getMessage()
           ); 
           $this->displayError('For configuration "CONTODEO_API_PRIVATE_KEY_TEST" an exception was thrown: ' . $e->getMessage());
       } catch (\Wha\Contodeo\utils\MissingDataException $e) {
           $this->logger->debug('The configuration "CONTODEO_API_PRIVATE_KEY_TEST" has no value set.');
           $this->displayError('The configuration "CONTODEO_API_PRIVATE_KEY_TEST" has no value set.' . $e->getMessage());
       }

       $apiKeyTestLastDigits = Tools::substr($apiKeyTest, -4);

       $fields_form[0]['form']['input'][] = array(
           'type' => 'password',
           'label' => $this->l('API secret key for Test'),
           'name' => 'CONTODEO_API_PRIVATE_KEY_TEST',
           'desc' => $apiKeyTestLastDigits ? $this->l('Saved key ends in: ') . $apiKeyTestLastDigits : $this->l('Please fill your API secret key for Test'),
           'class' => $apiKeyTestLastDigits ? 'contodeo-input-green' : '',
           'size' => 20,
           'required' => true,
           'hint' => $this->l('If you don\'t know your Api private key, log in to your Contodeo Dashboard. Navigate to Merchant tab. The key is display on the upper part of the page.')

       );
       
       $apiKeyLive = '';

       try {
           $apiKeyLive = $this->crypto->decrypt(Configuration::get('CONTODEO_API_PRIVATE_KEY_LIVE'));
       } catch (\Wha\Contodeo\utils\GenericLoggedException $e) {
           $this->logger->error(
               'For configuration "CONTODEO_API_PRIVATE_KEY_LIVE" an exception was thrown: ' . $e->getMessage()
           ); 
           $this->displayError('For configuration "CONTODEO_API_PRIVATE_KEY_LIVE" an exception was thrown: ' . $e->getMessage());
       } catch (\Wha\Contodeo\utils\MissingDataException $e) {
           $this->logger->debug('The configuration "CONTODEO_API_PRIVATE_KEY_LIVE" has no value set.');
           $this->displayError('The configuration "CONTODEO_API_PRIVATE_KEY_LIVE" has no value set.' . $e->getMessage());
       } 

       $apiKeyLiveLastDigits = Tools::substr($apiKeyLive, -4);

       $fields_form[0]['form']['input'][] = array(
           'type' => 'password',
           'label' => $this->l('API secret key for Live'),
           'name' => 'CONTODEO_API_PRIVATE_KEY_LIVE',
           'desc' => $apiKeyLiveLastDigits ? $this->l('Saved key ends in: ') . $apiKeyLiveLastDigits : $this->l('Please fill your API key for Production'),
           'class' => $apiKeyLiveLastDigits ? 'contodeo-input-green' : '',
           'size' => 20,
           'required' => false,
           'hint' =>$this->l('If you don\'t know your Api private key, log in to your Contodeo Dashboard. Navigate to Merchant tab. The key is display on the upper part of the page.')

       );

        // Test/Production mode
        $fields_form[1]['form']['input'][] = array(
            'type' => 'radio',
            'label' => $this->l('Test/Production Mode'),
            'name' => 'CONTODEO_MODE',
            'values' => array(
                array(
                    'id' => 'prod',
                    'value' => 'live',
                    'label' => $this->l('Production')
                ),
                array(
                    'id' => 'test',
                    'value' => 'test',
                    'label' => $this->l('Test')
                )
            ),
            'required' => true,
            'hint' => $this->l('In test mode all payment do not produce real transactions.')
        );

        // Confirmation mode
        $fields_form[1]['form']['input'][] = array(
            'type' => 'radio',
            'label' => $this->l('Confirmation Mode'),
            'name' => 'CONTODEO_CONFIRM_MODE',
            'values' => array(
                array(
                    'id' => 'auto',
                    'value' => 'auto',
                    'label' => $this->l('Auto')
                ),
                array(
                    'id' => 'manual',
                    'value' => 'manual',
                    'label' => $this->l('Manual').' '.$this->l('(Be carefull. You will have to manually confirm the transaction into the contodeo dashboard)')
                ),
                array(
                    'id' => 'onDispatch',
                    'value' => 'onDispatch',
                    'label' => $this->l('On dispatch')
                )
            ),
            'required' => true,
            'hint' => $this->l('Choose the confirmation mode according to your activity.')
        ); 

        // Test/Production mode
        $fields_form[1]['form']['input'][] = array(
            'type' => 'radio',
            'label' => $this->l('Display registered card'),
            'name' => 'CONTODEO_DISPLAY_REGISTERED_CARD',
            'values' => array(
                array(
                    'id' => 'true',
                    'value' => 'true',
                    'label' => $this->l('true')
                ),
                array(
                    'id' => 'false',
                    'value' => 'false',
                    'label' => $this->l('false')
                )
            ),
            'required' => true
        );

         // Confirmation mode
         $fields_form[1]['form']['input'][] = array(
            'type' => 'radio',
            'label' => $this->l('Register Mode'),
            'name' => 'CONTODEO_REGISTER_MODE',
            'values' => array(
                array(
                    'id' => 'no',
                    'value' => 'no',
                    'label' => $this->l('No')
                ),
                array(
                    'id' => 'suggest',
                    'value' => 'suggest',
                    'label' => $this->l('Suggest')
                ),
                array(
                    'id' => 'suggest_mandatory',
                    'value' => 'suggest_mandatory',
                    'label' => $this->l('Suggest and mandatory')
                )
            ),
            'required' => true
        ); 

       

      
        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;

        // Language
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;

        // Title and toolbar
        $helper->title = $this->displayName;
        $helper->show_toolbar = true; // false -> remove toolbar
        $helper->toolbar_scroll = true; // yes - > Toolbar is always visible on the top of the screen.
        $helper->submit_action = 'submit' . $this->name;
        $helper->toolbar_btn = array(
            'save' => array(
                'desc' => $this->l('Save'),
                'href' => sprintf(
                    "%s&configure=%s&save%s&token=%s",
                    AdminController::$currentIndex,
                    $this->name,
                    $this->name,
                    Tools::getAdminTokenLite('AdminModules')
                )
            ),
            'back' => array(
                'href' => AdminController::$currentIndex . '&token=' . Tools::getAdminTokenLite('AdminModules'),
                'desc' => $this->l('Back to list')
            )
        );
       
        if (Tools::isSubmit('submit' . $this->name)) {
            // get settings from post because post can give errors and you want to keep values
            $merchant_account = (string)Tools::getValue('CONTODEO_API_PUBLIC_KEY');
            $mode = (string)Tools::getValue('CONTODEO_MODE');
            $confirmationMode= (string)Tools::getValue('CONTODEO_CONFIRM_MODE');
            $registerMode= (string)Tools::getValue('CONTODEO_REGISTER_MODE');
            $displayRegisteredCard= (string)Tools::getValue('CONTODEO_DISPLAY_REGISTERED_CARD');
        } else {
            $merchant_account = Configuration::get('CONTODEO_API_PUBLIC_KEY');
            $mode = Configuration::get('CONTODEO_MODE');
            $confirmationMode= Configuration::get('CONTODEO_CONFIRM_MODE');
            $registerMode= Configuration::get('CONTODEO_REGISTER_MODE');
            $displayRegisteredCard= Configuration::get('CONTODEO_DISPLAY_REGISTERED_CARD');
        }

        // Load current value
        $helper->fields_value['CONTODEO_API_PUBLIC_KEY'] = $merchant_account;
        $helper->fields_value['CONTODEO_MODE'] = $mode;
        $helper->fields_value['CONTODEO_CONFIRM_MODE'] = $confirmationMode;
        $helper->fields_value['CONTODEO_REGISTER_MODE'] = $registerMode;
        $helper->fields_value['CONTODEO_DISPLAY_REGISTERED_CARD'] = $displayRegisteredCard;

        return $helper->generateForm($fields_form);
    }
    
}
