<?php

use \Wha\Contodeo\services\Proxy;
use \Wha\Contodeo\Services\Transaction;
use Wha\Contodeo\utils\ConfirmationMode;

class ContodeoResultModuleFrontController extends ModuleFrontController
{
    /**
     * var Proxy
     */
//    private $proxy;

    /* public function __construct(){
        
    }
 */
    public function initContent()
    {
        parent::initContent();
        $this->proxy=\Wha\Contodeo\services\ContodeoServiceLocator::get('\\Wha\\Contodeo\\services\\Proxy');
        $this->transaction=\Wha\Contodeo\services\ContodeoServiceLocator::get('\\Wha\\Contodeo\\services\\Transaction');
        $this->orderService=\Wha\Contodeo\services\ContodeoServiceLocator::get('\\Wha\\Contodeo\\services\\Order');
        $this->configuration=\Wha\Contodeo\services\ContodeoServiceLocator::get("\\Wha\Contodeo\utils\Configuration");
        $this->transactionModel=\Wha\Contodeo\services\ContodeoServiceLocator::get("\\Wha\Contodeo\models\ContodeoTransaction");
        $this->walletModel=\Wha\Contodeo\services\ContodeoServiceLocator::get("\\Wha\Contodeo\models\ContodeoWallet");
        $this->logger = \Wha\Contodeo\services\ContodeoServiceLocator::get('\\Wha\Contodeo\services\Logger');

        $this->logger->info("Process transaction return".\Tools::getValue('trx_id'));        
        $dataReturn=$this->proxy->getTransaction(\Tools::getValue('trx_id'));
        $cart = new \Cart($dataReturn->external_id);
        $this->logger->info("Process return for cart ".$dataReturn->external_id);  
      
         // Validate if cart exists - if not redirect back to order page
         if (!\Validate::isLoadedObject($cart)) {
             \Tools::redirect($this->context->link->getPageLink('order', $this->ssl));
         }

         $total = (float)$cart->getOrderTotal(true, \Cart::BOTH);
         $customer = new \Customer($cart->id_customer);
         $extraVars= array('transaction_id'=>$dataReturn->id);


         $resultCode = $dataReturn->status;
         $redirectUrl ='';
         $returnTemplate='module:contodeo/views/templates/front/paymentReturn.tpl';

         $this->transactionModel-> insertTransaction($cart->id,null, $resultCode, $dataReturn);

         //Card wad registered with a wallet 
         if($dataReturn->wallet_id!==null){
            //Enregistrement du wallet 
            $this->walletModel->insertWallet($customer->id,$dataReturn->wallet_id);
            $this->logger->info('Register wallet for customer : '. $customer->id .  'wallet ' .$dataReturn->wallet_id );
         }
         // Based on the result code start different payment flows
         switch ($resultCode) {
             case 'CONFIRMED':
                 $this->module->validateOrder(
                     $cart->id,
                     \Configuration::get('PS_OS_PAYMENT'),
                     $total,
                     $this->module->displayName,
                     null,
                     $extraVars,
                     (int)$cart->id_currency,
                     false,
                     $customer->secure_key
                 );
 
                 $newOrder = new \Order((int)$this->module->currentOrder);
                 $this->transactionModel-> updateTransactionByCartId($cart->id,$newOrder->id, $resultCode, $dataReturn);

                 $redirectUrl=
                     $this->context->link->getPageLink(
                         'order-confirmation',
                         $this->ssl,
                         null,
                         sprintf(
                             "id_cart=%s&id_module=%s&id_order=%s&key=%s",
                             $cart->id,
                             $this->module->id,
                             $this->module->currentOrder,
                             $customer->secure_key
                         )
                         );
                $this->orderService->addPaymentDataToOrderFromResponse($newOrder, $dataReturn); 
                        break;
                case 'AUTHORIZED':
                    $this->module->validateOrder(
                        $cart->id,
                        \Configuration::get('CONTODEO_OS_WAITING_FOR_PAYMENT'),
                        $total,
                        $this->module->displayName,
                        null,
                        $extraVars,
                        (int)$cart->id_currency,
                        false,
                        $customer->secure_key
                    );


                    $newOrder = new \Order((int)$this->module->currentOrder);
                    $this->orderService->addPaymentDataToOrderFromResponse($newOrder, $dataReturn); 

                    
                    $this->transactionModel-> updateTransactionByCartId($cart->id,$newOrder->id, $resultCode, $dataReturn);
                    error_log('Retourn simple authorize Confirmation mode:'.$this->configuration->confirmationMode);
                    if($this->configuration->confirmationMode==ConfirmationMode::AUTO)
                    {
                       error_log('Confirm auto send');
                       $confirmResult= $this->transaction->confirmTransaction($newOrder,$dataReturn->id) ;
                       if($confirmResult->status=='CONFIRMED'){
                           $history = new OrderHistory();
                           $history->changeIdOrderState(\Configuration::get('PS_OS_PAYMENT'), $newOrder->id);
                       }
                    }

                    $redirectUrl=
                        $this->context->link->getPageLink(
                            'order-confirmation',
                            $this->ssl,
                            null,
                            sprintf(
                                "id_cart=%s&id_module=%s&id_order=%s&key=%s",
                                $cart->id,
                                $this->module->id,
                                $this->module->currentOrder,
                                $customer->secure_key
                            )
                            );
                   
                    break;
                case 'FAILED':
                    $redirectUrl=$this->context->link->getPageLink('order', $this->ssl); 
                    $returnTemplate='module:contodeo/views/templates/front/paymentFailure.tpl';
                    $this->context->smarty->assign(['trxAmount'=>$dataReturn->amount,
                                                     'trxDate' =>$dataReturn->creation_date,
                                                     'trxRef'=>$dataReturn->id]);


                break;
            }
            $this->context->smarty->assign([
                'redirectUrl' => $redirectUrl
            ]);
            error_log("Avant affichage du paymentReturn:".$redirectUrl);
            
            $this->setTemplate($returnTemplate);
    }
}
