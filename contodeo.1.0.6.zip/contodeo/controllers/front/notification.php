<?php

use \Wha\Contodeo\services\Proxy;
use \Wha\Contodeo\Services\Transaction;
use Wha\Contodeo\utils\ConfirmationMode;

class ContodeoNotificationModuleFrontController extends ModuleFrontController
{
 
    public function __construct()
    {
        $this->configuration=\Wha\Contodeo\services\ContodeoServiceLocator::get("\\Wha\Contodeo\utils\Configuration");
        $this->logger = \Wha\Contodeo\services\ContodeoServiceLocator::get('\\Wha\Contodeo\services\Logger');
        $this->transactionService = \Wha\Contodeo\services\ContodeoServiceLocator::get('\\Wha\Contodeo\services\Transaction');
        $this->contodeoTransaction = \Wha\Contodeo\services\ContodeoServiceLocator::get('\\Wha\Contodeo\models\ContodeoTransaction');
        parent::__construct();
    }

    function postProcess()
    {

        

        $rawData =\Tools::file_get_contents('php://input');
        $data=json_decode($rawData);
        $this->logger->info('Process receive notification'.$rawData);

        //$transaction= $this->contodeoTransaction->getTransactionByTransactionId($data->transaction_id);
        $this->logger->info('Check transaction status ' . $data->transaction_id);
        $orderId=$this->contodeoTransaction->getOrderIdByTransactionId($data->transaction_id);
        $order = new \Order((int)$orderId);

        
        if($data->action =='TRX_AUTHORIZE_EXPIRED'){
            $this->logger->info('Authorization expiration notification received process order :'. $orderId);
            $result=$this->transactionService->getTransaction($data->transaction_id);
            $this->contodeoTransaction->updateTransactionByTransactionId($result->id,$result->status,$result);

            //change status of the order
            //if($result->status='EXPIRED'){
                $history = new OrderHistory();
                $history->changeIdOrderState(\Configuration::get('CONTODEO_OS_AUTHORIZE_EXPIRED'), $order->id);
                $this->logger->info('Change to status '.\Configuration::get('CONTODEO_OS_AUTHORIZE_EXPIRED').'for order'.$order->id);
           // }
        }
        
      
        $this->setTemplate('module:contodeo/views/templates/front/void.tpl');
    }
}
